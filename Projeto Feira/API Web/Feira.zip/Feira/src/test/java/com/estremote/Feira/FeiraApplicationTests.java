package com.estremote.Feira;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
